# -*- coding: utf-8 -*-

# This sample demonstrates handling intents from an Alexa skill using the Alexa Skills Kit SDK for Python.
# Please visit https://alexa.design/cookbook for additional examples on implementing slots, dialog management,
# session persistence, api calls, and more.
# This sample is built using the handler classes approach in skill builder.
from ask_sdk_core.skill_builder import SkillBuilder
from ask_sdk_core.dispatch_components import (AbstractRequestHandler, AbstractExceptionHandler,AbstractResponseInterceptor, AbstractRequestInterceptor)
from ask_sdk_core.handler_input import HandlerInput
from ask_sdk_core.attributes_manager import AttributesManager
from ask_sdk_dynamodb.adapter import DynamoDbAdapter
#from ask_sdk_core.utils import get_supported_interfaces 
from ask_sdk_model.interfaces.alexa.presentation.apl import (
	    RenderDocumentDirective, ExecuteCommandsDirective, SpeakItemCommand,
	    AutoPageCommand, HighlightMode)
from ask_sdk_model import Response
import logging
import os
import boto3
import json
import ask_sdk_core.utils as ask_utils
import random
#s3_adapter = S3Adapter(bucket_name = os.environ["S3_PERSISTENCE_BUCKET"])

def _load_apl_document(file_path):
    # type: (str) -> Dict[str, Any]
    """Load the apl json document at the path into a dict object."""
    with open(file_path) as f:
        return json.load(f)

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

class LaunchRequestHandler(AbstractRequestHandler):
    """Handler for Skill Launch."""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool

        return ask_utils.is_request_type("LaunchRequest")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        language_prompts = handler_input.attributes_manager.request_attributes["_"]
        speak_output = language_prompts["WELCOME_MESSAGE_1"]
        reprompt_text = language_prompts["REPROMPT_MESSAGE_WELCOME"]
        
        sessionDatabase = handler_input.attributes_manager.session_attributes
        if not sessionDatabase:
            sessionDatabase["list_c"] = ""
            sessionDatabase["answerQuestion"] = 0
            sessionDatabase["gametype"] = ""
            sessionDatabase["difficulty"] = ""
            sessionDatabase["sessionPoints"] = 0
            sessionDatabase["gameTotalScore"] = 0
            sessionDatabase["readyOrNot"] = False
       
        handler_input.attributes_manager.session_attributes = sessionDatabase
        return (
                handler_input.response_builder
                    .speak(speak_output)
                    .ask(reprompt_text)
                    .set_should_end_session(False)
                    .add_directive(
                        RenderDocumentDirective(
                            token="pagerToken",
                            document=_load_apl_document("begin.json")
                        )
                    )
                    .response
        )


class InitializeGameIntentHandler(AbstractRequestHandler):
    """Handler for Initialize Game Intent."""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return ask_utils.is_intent_name("InitializeGameIntent")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        language_prompts = handler_input.attributes_manager.request_attributes["_"]
        list_colors = language_prompts["GAME_COLORS"].split(",")
        code_list_colors = language_prompts["GAME_COLORS_CODE"].split(",")
        #
        slots = handler_input.request_envelope.request.intent.slots
        difficulty = slots["difficulty"].value
        gametype = slots["gametype"].value
        #
        values_r = handler_input.attributes_manager.session_attributes
        #
        random_colors_sequence = []
        phrase_colors = ""
        sequence_colors = ""
        points = 0
        delay = 0
        number = 0
        
        if difficulty.lower() == language_prompts["DIFFICULTY_EASY"]:
            number = 4
            points = 10
            delay = 2000
        elif difficulty.lower() == language_prompts["DIFFICULTY_MEDIUM"]:
            number = 7
            points = 30
            delay = 1000
        elif difficulty.lower() == language_prompts["DIFFICULTY_HARD"]:
            number = 10
            points = 60
            delay = 500

        for x in range(0,number):
            random_number = random.randint(0,len(list_colors)-1)
            choose_color = list_colors[random_number]
            random_colors_sequence.append(choose_color)
            sequence_colors += code_list_colors[random_number] + ", "
            phrase_colors += choose_color + ", "

        if gametype == language_prompts["GAMETYPE_VISUAL"]:
            speak_output = language_prompts["VISUAL_QUESTION"] + language_prompts["CHOOSE_QUESTION"]
            reprompt_text = language_prompts["REPROMPT_MESSAGE_GAME"] + phrase_colors
            
            client = boto3.client('iot-data', region_name='us-east-1')
            response = client.publish(
                topic='esp32/sub',
                qos=1,
                payload=json.dumps({"sequence":sequence_colors,"delay":delay})
            )
            
        elif gametype == language_prompts["GAMETYPE_VOICE"]:
            speak_output = language_prompts["PHRASE_REPEAT_SEQ"] + phrase_colors  #after sequence say question or ready question  
            reprompt_text = language_prompts["REPROMPT_MESSAGE_GAME"]
        else:
            speak_output = phrase_colors + language_prompts["CHOOSE_QUESTION"]
            reprompt_text = language_prompts["REPROMPT_MESSAGE_GAME"]
        
        values_r["readyOrNot"] = False
        values_r["list_c"] = random_colors_sequence
        values_r["gametype"] = gametype
        values_r["difficulty"] = difficulty
        values_r["sessionPoints"] = points
        values_r["answerQuestion"] = 0
        
        handler_input.attributes_manager.session_attributes = values_r
        return (
                handler_input.response_builder
                    .speak(speak_output)
                    .set_should_end_session(False)
                    .ask(reprompt_text)
                    .add_directive(
                        RenderDocumentDirective(
                            token="pagerToken",
                            document=_load_apl_document("begin.json")
                        )
                    )
                    .response
            )


class ScoreIntentHandler(AbstractRequestHandler):
    """Handler for Score Intent Intent."""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return ask_utils.is_intent_name("ScoreIntent")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        language_prompts = handler_input.attributes_manager.request_attributes["_"]
        sessionDatabase = handler_input.attributes_manager.session_attributes
        difficulty = sessionDatabase["difficulty"]
        list_c = sessionDatabase["list_c"]
        answerQuestion = sessionDatabase["answerQuestion"]
        readyOrNot = sessionDatabase["readyOrNot"]
        slots = handler_input.request_envelope.request.intent.slots
        wordList = []
        
        if(language_prompts["LOCALE"] == "BR" ):
            wordList.append(slots["SequenceColorsUm"].value)
            wordList.append(slots["SequenceColorsDois"].value)
            wordList.append(slots["SequenceColorsTres"].value)
            wordList.append(slots["SequenceColorsQuatro"].value)
            if difficulty.lower() == language_prompts["DIFFICULTY_MEDIUM"]:
                wordList.append(slots["SequenceColorsCinco"].value)
                wordList.append(slots["SequenceColorsSeis"].value)
                wordList.append(slots["SequenceColorsSete"].value)
            elif difficulty.lower() == language_prompts["DIFFICULTY_HARD"]:
                wordList.append(slots["SequenceColorsOito"].value)
                wordList.append(slots["SequenceColorsNove"].value)
                wordList.append(slots["SequenceColorsDez"].value)
        else:
            wordList = slots["SequenceColors"].value.split()
        
        #if list_c == wordList:
        #    winGame = True
        #else:
        #    winGame = False
        logger.info("Locale is {} e {}".format(len(wordList), len(list_c)))
        if not readyOrNot:
            speak_output = language_prompts["READY_OR_NOT"]
            return (
            handler_input.response_builder
                .speak(speak_output)
                .set_should_end_session(False)
                # .ask("add a reprompt if you want to keep the session open for the user to respond")
                .response
            )
        elif answerQuestion > 0:
            speak_output = language_prompts["WRONG_QUESTION_1"]
            return (
            handler_input.response_builder
                .speak(speak_output)
                .set_should_end_session(False)
                # .ask("add a reprompt if you want to keep the session open for the user to respond")
                .response
            )
        elif not list_c:
            speak_output = language_prompts["CHOOSE_GAMEMODE"]
            return (
            handler_input.response_builder
                .speak(speak_output)
                .set_should_end_session(False)
                # .ask("add a reprompt if you want to keep the session open for the user to respond")
                .response
            )
            
        elif len(wordList) != len(list_c):
            speak_output = language_prompts["CHECK_RESULT"].format(len(list_c),len(wordList))
            return (
            handler_input.response_builder
                .speak(speak_output)
                .set_should_end_session(False)
                # .ask("add a reprompt if you want to keep the session open for the user to respond")
                .response
            )
        
        winGame = True
        for x in range(0,len(list_c)):
            if list_c[x].strip().lower() != wordList[x].strip().lower():
                logger.info("Locale dsasdasdasdas {} e {}".format(list_c[x], wordList[x]))
                winGame = False
                break;

        if winGame:
            speak_output = language_prompts["CONGRATULATIONS_MESSAGE"]
            sessionDatabase["readyOrNot"] = False
            sessionDatabase["list_c"] = ""
            sessionDatabase["gameTotalScore"] += sessionDatabase["sessionPoints"]
            sessionDatabase["sessionPoints"] = 0
            return (
            handler_input.response_builder
                .speak(speak_output)
                .add_directive(
                        RenderDocumentDirective(
                            token="pagerToken",
                            document=_load_apl_document("Congratulations.json")
                        )
                    )
                .set_should_end_session(False)
                # .ask("add a reprompt if you want to keep the session open for the user to respond")
                .response
        )
        else:
            speak_output = language_prompts["TRY_AGAIN_MESSAGE"]
            
        handler_input.attributes_manager.session_attributes = sessionDatabase

        return (
            handler_input.response_builder
                .speak(speak_output)
                .set_should_end_session(False)
                .add_directive(
                        RenderDocumentDirective(
                            token="pagerToken",
                            document=_load_apl_document("tryagain.json")
                        )
                    )
                # .ask("add a reprompt if you want to keep the session open for the user to respond")
                .response
        )
        
class ScoreNumberIntentHandler(AbstractRequestHandler):
    """Handler for Score Intent Intent."""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return ask_utils.is_intent_name("ScoreNumberIntent")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        language_prompts = handler_input.attributes_manager.request_attributes["_"]
        sessionDatabase = handler_input.attributes_manager.session_attributes
        answerQuestion = sessionDatabase["answerQuestion"]
        readyOrNot = sessionDatabase["readyOrNot"]
        slots = handler_input.request_envelope.request.intent.slots
        num = slots["num"].value
        if not readyOrNot:
            speak_output = language_prompts["READY_OR_NOT"]
            return (
            handler_input.response_builder
                .speak(speak_output)
                .set_should_end_session(False)
                # .ask("add a reprompt if you want to keep the session open for the user to respond")
                .response
            )
        elif answerQuestion == 0:
            speak_output = language_prompts["WRONG_QUESTION_2"]
            return (
            handler_input.response_builder
                .speak(speak_output)
                .set_should_end_session(False)
                # .ask("add a reprompt if you want to keep the session open for the user to respond")
                .response
            )
        elif answerQuestion == int(num):
            speak_output = language_prompts["CONGRATULATIONS_MESSAGE"]
            sessionDatabase["list_c"] = ""
            sessionDatabase["gameTotalScore"] += sessionDatabase["sessionPoints"]
            sessionDatabase["sessionPoints"] = 0
            sessionDatabase["answerQuestion"] = 0
            sessionDatabase["readyOrNot"] = False
            return (
            handler_input.response_builder
                .speak(speak_output)
                .set_should_end_session(False)
                .add_directive(
                        RenderDocumentDirective(
                            token="pagerToken",
                            document=_load_apl_document("Congratulations.json")
                        )
                    )
                # .ask("add a reprompt if you want to keep the session open for the user to respond")
                .response
        )
        else:
            speak_output = language_prompts["TRY_AGAIN_MESSAGE"]
            
        handler_input.attributes_manager.session_attributes = sessionDatabase

        return (
            handler_input.response_builder
                .speak(speak_output)
                .set_should_end_session(False)
                .add_directive(
                        RenderDocumentDirective(
                            token="pagerToken",
                            document=_load_apl_document("tryagain.json")
                        )
                    )
                # .ask("add a reprompt if you want to keep the session open for the user to respond")
                .response
        )

class QuestionIntentHandler(AbstractRequestHandler):
    """Handler for Help Intent."""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return ask_utils.is_intent_name("QuestionIntent")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        language_prompts = handler_input.attributes_manager.request_attributes["_"]
        sessionDatabase = handler_input.attributes_manager.session_attributes
        speak_output = ""
        random_number = random.randint(0,1)
        
        if random_number == 0:
            speak_output = language_prompts["RANDOM_QUESTION_1"]
        elif random_number == 1:
            list_c = sessionDatabase["list_c"]
            color = random.choice(list_c)
            sessionDatabase["answerQuestion"] = list_c.count(color)
            speak_output = language_prompts["RANDOM_QUESTION_2"].format(color)
        
        sessionDatabase["readyOrNot"] = True
        handler_input.attributes_manager.session_attributes = sessionDatabase
        
        return (
            handler_input.response_builder
                .speak(speak_output)
                .ask(speak_output)
                .set_should_end_session(False)
                .add_directive(
                        RenderDocumentDirective(
                            token="pagerToken",
                            document=_load_apl_document("begin.json")
                        )
                    )
                .response
        )

class HelpIntentHandler(AbstractRequestHandler):
    """Handler for Help Intent."""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return ask_utils.is_intent_name("AMAZON.HelpIntent")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        language_prompts = handler_input.attributes_manager.request_attributes["_"]
        speak_output = language_prompts["HELP_MESSAGE"]
        
        return (
            handler_input.response_builder
                .speak(speak_output)
                .ask(speak_output)
                .set_should_end_session(False)
                .add_directive(
                        RenderDocumentDirective(
                            token="pagerToken",
                            document=_load_apl_document("begin.json")
                        )
                    )
                .response
        )

class InformationIntentHandler(AbstractRequestHandler):
    """Handler for Help Intent."""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return ask_utils.is_intent_name("InformationIntent")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        language_prompts = handler_input.attributes_manager.request_attributes["_"]
        slots = handler_input.request_envelope.request.intent.slots
        rules = slots["rules"].value
        
        if not rules:
            speak_output = language_prompts["INFORMATION_MESSAGE"]
        else:
            speak_output = language_prompts["RULES_MESSAGE"]
        
        return (
            handler_input.response_builder
                .speak(speak_output)
                .ask(speak_output)
                .set_should_end_session(False)
                .add_directive(
                        RenderDocumentDirective(
                            token="pagerToken",
                            document=_load_apl_document("begin.json")
                        )
                    )
                .response
        )
    
class RankingIntentHandler(AbstractRequestHandler):
    """Handler for Help Intent."""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return ask_utils.is_intent_name("RankingIntent")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        #
        language_prompts = handler_input.attributes_manager.request_attributes["_"]
        tempDatabase = handler_input.attributes_manager.session_attributes
        dynamodb = boto3.resource('dynamodb')
        table = dynamodb.Table('users_score')
        #
        slots = handler_input.request_envelope.request.intent.slots
        action = slots["action"].value 
        name = slots["name"].value + " " + slots["lastName"].value
        
        response = table.get_item(Key={"username":name})
        #
        if action.lower() == language_prompts["ACTION_REGISTER"]:
            if 'Item' not  in response:
                speak_output = language_prompts["SUCCESS_REGISTER"].format(name,tempDatabase["gameTotalScore"])
                table.put_item(
                        Item={
                                'username': name,
                                'score':tempDatabase["gameTotalScore"]
                            })
            else:
                if int(response['Item']['score']) > int(tempDatabase["gameTotalScore"]):
                    speak_output = language_prompts["REGISTER_CHECK"].format(name,response['Item']['score'])
                else:
                    speak_output = language_prompts["REGISTER_OVER_SUCCESS"].format(name,tempDatabase["gameTotalScore"])
                    table.update_item(
                            Key={"username":name},
                            UpdateExpression="SET score= :score",
                            ExpressionAttributeValues={':score':tempDatabase["gameTotalScore"]}
                        )
        elif action.lower() == language_prompts["ACTION_DELETE"]:
            if 'Item' not  in response:
                speak_output = language_prompts["FAIL_DELETE"].format(name)
            else:
                table.delete_item(
                    Key={"username":name}
                )
                speak_output = language_prompts["FAIL_SUCCESS"].format(name)
        
        tempDatabase["gameTotalScore"] = 0
        #sorted_dict = dict(sorted(database.items(), key=lambda item: item[1],reverse = True))
        handler_input.attributes_manager.session_attributes = tempDatabase
        return (
            handler_input.response_builder
                .speak(speak_output)
                .ask(speak_output)
                .set_should_end_session(False)
                .add_directive(
                        RenderDocumentDirective(
                            token="pagerToken",
                            document=_load_apl_document("begin.json")
                        )
                    )
                .response
        )

class ShowRankingIntentHandler(AbstractRequestHandler):
    """Handler for Help Intent."""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return ask_utils.is_intent_name("ShowRankingIntent")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        #
        language_prompts = handler_input.attributes_manager.request_attributes["_"]
        dynamodb = boto3.resource('dynamodb')
        table = dynamodb.Table('users_score')
        users = table.scan()['Items']
        users.sort(key=lambda x: int(x["score"]),reverse=True)
        speak_output = ""
        #
        slots = handler_input.request_envelope.request.intent.slots
        indexUser = 0
        if slots["playerName"].value == None:
            name = ""
        else:
            name = slots["playerName"].value + " " + slots["playerLastName"].value
        #
        print(users)
        for x in range(0,len(users)):
            if x <= 2:
                speak_output +=  language_prompts["SHOW_SCORE_" + str(x)].format(users[x]["username"],users[x]["score"])
            if name.lower() == users[x]["username"].lower():
                indexUser = x+1
            if (indexUser > 0 or not name) and x > 2:
                break

        if name:
            response = table.get_item(Key={"username":name})
            if 'Item' not in response:
                speak_output = language_prompts["FAIL_SHOW_SCORE"]
            else:
                speak_output += language_prompts["SHOW_SCORE"].format(indexUser,response["Item"]["score"])
        return (
            handler_input.response_builder
                .speak(speak_output)
                .ask(speak_output)
                .set_should_end_session(False)
                .add_directive(
                        RenderDocumentDirective(
                            token="pagerToken",
                            document=_load_apl_document("begin.json")
                        )
                    )
                .response
        )

class CancelOrStopIntentHandler(AbstractRequestHandler):
    """Single handler for Cancel and Stop Intent."""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return (ask_utils.is_intent_name("AMAZON.CancelIntent")(handler_input) or
                ask_utils.is_intent_name("AMAZON.StopIntent")(handler_input))

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        language_prompts = handler_input.attributes_manager.request_attributes["_"]
        speak_output = language_prompts["GOODBYE_MESSAGE"]

        return (
            handler_input.response_builder
                .speak(speak_output)
                .set_should_end_session(True)
                .add_directive(
                        RenderDocumentDirective(
                            token="pagerToken",
                            document=_load_apl_document("begin.json")
                        )
                    )
                .response
        )

class SessionEndedRequestHandler(AbstractRequestHandler):
    """Handler for Session End."""
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return ask_utils.is_request_type("SessionEndedRequest")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response

        # Any cleanup logic goes here.

        return handler_input.response_builder.response


class IntentReflectorHandler(AbstractRequestHandler):
    """The intent reflector is used for interaction model testing and debugging.
    It will simply repeat the intent the user said. You can create custom handlers
    for your intents by defining them above, then also adding them to the request
    handler chain below.
    """
    def can_handle(self, handler_input):
        # type: (HandlerInput) -> bool
        return ask_utils.is_request_type("IntentRequest")(handler_input)

    def handle(self, handler_input):
        # type: (HandlerInput) -> Response
        intent_name = ask_utils.get_intent_name(handler_input)
        speak_output = "You just triggered " + intent_name + "."

        return (
            handler_input.response_builder
                .speak(speak_output)
                # .ask("add a reprompt if you want to keep the session open for the user to respond")
                .response
        )


class CatchAllExceptionHandler(AbstractExceptionHandler):
    """Generic error handling to capture any syntax or routing errors. If you receive an error
    stating the request handler chain is not found, you have not implemented a handler for
    the intent being invoked or included it in the skill builder below.
    """
    def can_handle(self, handler_input, exception):
        # type: (HandlerInput, Exception) -> bool
        return True

    def handle(self, handler_input, exception):
        # type: (HandlerInput, Exception) -> Response
        logger.error(exception, exc_info=True)
        language_prompts = handler_input.attributes_manager.request_attributes["_"]
        speak_output = language_prompts["ERROR_MESSAGE"]

        return (
            handler_input.response_builder
                .speak(speak_output)
                .ask(speak_output)
                .response
        )

class LocalizationInterceptor(AbstractRequestInterceptor):

    def process(self, handler_input):
        locale = handler_input.request_envelope.request.locale
        try:
            with open("languages/"+str(locale)+".json") as language_data:
                language_prompts = json.load(language_data)
        except:
            with open("languages/"+ str(locale[:2]) +".json") as language_data:
                language_prompts = json.load(language_data)
        
        handler_input.attributes_manager.request_attributes["_"] = language_prompts


# The SkillBuilder object acts as the entry point for your skill, routing all request and response
# payloads to the handlers above. Make sure any new handlers or interceptors you've
# defined are included below. The order matters - they're processed top to bottom.

sb = SkillBuilder()

sb.add_request_handler(LaunchRequestHandler())
sb.add_request_handler(InitializeGameIntentHandler())
sb.add_request_handler(ScoreIntentHandler())
sb.add_request_handler(QuestionIntentHandler())
sb.add_request_handler(ScoreNumberIntentHandler())
sb.add_request_handler(InformationIntentHandler())
sb.add_request_handler(RankingIntentHandler())
sb.add_request_handler(ShowRankingIntentHandler())
sb.add_request_handler(HelpIntentHandler())
sb.add_request_handler(CancelOrStopIntentHandler())
sb.add_request_handler(SessionEndedRequestHandler())
#sb.add_request_handler(IntentReflectorHandler()) # make sure IntentReflectorHandler is last so it doesn't override your custom intent handlers

sb.add_exception_handler(CatchAllExceptionHandler())

sb.add_global_request_interceptor(LocalizationInterceptor())

lambda_handler = sb.lambda_handler()